from django.shortcuts import render, redirect
from django.contrib.auth.mixins import LoginRequiredMixin
from django.urls import reverse_lazy
from django.contrib.auth import login, logout, authenticate
from django.contrib import messages
from django.db.models import Q
from django.db.models.aggregates import Sum
from datetime import datetime
import calendar
from django.views.generic import  ListView, View, CreateView, UpdateView, DetailView, DeleteView
from .forms import LoginForm, MemberForm, IncomeForm, OutcomeForm, UnpaidForm, ConceptForm
from .models import Member, Concept, Income, Outcome, Unpaid
# Create your views here.



class LoginView(View):
    def get(self, request ):
        if request.user.is_authenticated:
            return redirect(reverse_lazy('dashboard'))
        form = LoginForm()
        return render(request, 'login.html', {'form': form})

    def post(self, request):
        form = LoginForm(request.POST)
        if form.is_valid():
            username = form.cleaned_data.get('username')
            password = form.cleaned_data.get('password')
            user = authenticate(username=username, password=password)
            print(username)
            if user is not None:
                login(request, user)
                return redirect(reverse_lazy('dashboard'))



        form = LoginForm(request.POST)
        return render(request, 'login.html', {'form': form})

class LogoutView(LoginRequiredMixin, View):
    login_url = reverse_lazy('login')
    def post(self, request):
        logout(request)
        return redirect( reverse_lazy('login') )

class DashboardView(LoginRequiredMixin, View):
    login_url = reverse_lazy('login')
    def get(self, request):
        recent_incomes = Income.objects.all().order_by('-id')[:5]
        recent_outcomes = Outcome.objects.all().order_by('-id')[:5]

        context = {
            'recent_incomes': recent_incomes,
            'recent_outcomes': recent_outcomes
        }
        return render(request, 'auth/dashboard.html', context )

class MembersView(LoginRequiredMixin, ListView):
    login_url = reverse_lazy('login')
    model = Member
    template_name = 'auth/members/index.html'
    context_object_name = 'members'
    paginate_by = 10
    ordering = '-id'
    
    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        context['members_view'] = True
        return context
    
class FilterMemberView(LoginRequiredMixin, View):
    login_url = reverse_lazy('login')
    def get(self, request):
        term =  request.GET.get('termino')
        members = Member.objects.filter( Q(first_name__icontains=term) | Q( last_name__icontains=term)).order_by('-id')
        context = {
            'members':members,
            'term': term,
            'members_view': True
        }
        
        
        return render(request, 'auth/members/index.html', context)
            
class CreateMemberView(LoginRequiredMixin, CreateView):
    login_url = reverse_lazy('login')
    model = Member
    template_name = 'auth/members/create.html'
    form_class = MemberForm
    success_url = reverse_lazy('members')
    def form_valid(self, form):
        messages.success(self.request, 'Miembro creado con exito')
        return super().form_valid(form)
    
    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        context['members_view'] = True
        return context

class UpdateMemberView(LoginRequiredMixin, UpdateView):
    login_url = reverse_lazy('login')
    model = Member
    template_name = 'auth/members/update.html'
    form_class = MemberForm
    success_url = reverse_lazy('members')
    
    def form_valid(self, form):
        messages.success(self.request, 'Miembro actualizado con exito')
        return super().form_valid(form)

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        context['members_view'] = True
        return context
        
class DeleteMemberView(LoginRequiredMixin, DeleteView):
    login_url = reverse_lazy('login')        
    model = Member
    template_name = 'auth/members/delete.html'
    success_url = reverse_lazy('members')
    
    def form_valid(self, form):
        messages.success(self.request, 'Miembro eliminado con exito')
        return super().form_valid(form)
    
    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        context['members_view'] = True
        return context

class BirthdaysView(LoginRequiredMixin, View):
    login_url = reverse_lazy('login')
    def get(self, request):
        months = [
            ('1', 'Enero'), ('2', 'Febrero'), ('3', 'Marzo'), ('4', 'Abril'),
            ('5', 'Mayo'), ('6', 'Junio'), ('7', 'Julio'), ('8', 'Agosto'),
            ('9', 'Septiembre'), ('10', 'Octubre'),('11', 'Noviembre'), ('12', 'Diciembre')
        ]
        current_month_number = datetime.now().month
        birthdays = Member.objects.filter(status=True, birthday_month=current_month_number)
        context = {
            'birthdays': birthdays,
            'months': months,
            'current_month': months[current_month_number-1],
            'birthdays_view': True
        }
        return render(request, 'auth/birthdays/index.html', context)
        
class FilterBirthdaysView(LoginRequiredMixin, View):
    login_url = reverse_lazy('login')
    def get(self, request):
        month = request.GET.get('month')
        months = [
            ('1', 'Enero'), ('2', 'Febrero'), ('3', 'Marzo'), ('4', 'Abril'),
            ('5', 'Mayo'), ('6', 'Junio'), ('7', 'Julio'), ('8', 'Agosto'),
            ('9', 'Septiembre'), ('10', 'Octubre'),('11', 'Noviembre'), ('12', 'Diciembre')
        ]
        birthdays = Member.objects.filter(status=True, birthday_month=month)
        context = {
            'birthdays': birthdays,
            'months': months,
            'current_month': months[int(month)-1],
            'birthdays_views': True
        }
        return render(request, 'auth/birthdays/index.html', context)


class IncomesView(LoginRequiredMixin, ListView):
    login_url = reverse_lazy('login')
    model = Income
    template_name = 'auth/incomes/index.html'
    context_object_name = 'incomes'
    paginate_by = 10    
    
    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        total_ingresos = Income.objects.aggregate(total=Sum('amount'))['total'] or 0
        total_gastos =  Outcome.objects.aggregate(
            total=Sum('amount'))['total'] or 0
        total_impuestos = Outcome.objects.aggregate(
            impuestos=Sum('tax'))['impuestos'] or 0
        
        disponible = float(total_ingresos - total_gastos - total_impuestos)
        
        context['incomes_view'] = True
        context['disponible'] = disponible
        context['total_ingresos'] = float(total_ingresos)
        return context

class CreateIncomeView(LoginRequiredMixin, CreateView):
    login_url = reverse_lazy('login')
    model = Income
    form_class = IncomeForm
    template_name = 'auth/incomes/create.html'
    success_url = reverse_lazy('incomes'
                               )
    def form_valid(self, form):
        messages.success(self.request, 'Ingreso creado con exito')
        try:
            malapaga = Unpaid.objects.get(member=form.instance.member, month=form.instance.month)
            malapaga.delete()
        except Exception as e:
            print(e)
        return super().form_valid(form)
    
    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        context['incomes_view'] = True
        return context
    
    
class FilterIncomesView(LoginRequiredMixin, View):
    login_url = reverse_lazy('login')
    def get(self, request):
        
        months = [
            ('1', 'Enero'), ('2', 'Febrero'), ('3', 'Marzo'), ('4', 'Abril'),
            ('5', 'Mayo'), ('6', 'Junio'), ('7', 'Julio'), ('8', 'Agosto'),
            ('9', 'Septiembre'), ('10', 'Octubre'),('11', 'Noviembre'), ('12', 'Diciembre')
        ]
        
        term = request.GET.get('term')
        month = request.GET.get('month')
        incomes = Income.objects.filter(Q(member__first_name__icontains=term)).order_by('-id')
        context = {
            'incomes': incomes,
            'incomes_view': True,
            'term':term,
            'month':month,
            'months':months
        }
        return render(request, 'auth/incomes/index.html', context)    
    
class UpdateIncomeView(LoginRequiredMixin, UpdateView):
    login_url = reverse_lazy('login')
    model = Income
    template_name = 'auth/incomes/update.html'
    form_class = IncomeForm
    success_url = reverse_lazy('incomes')
    def form_valid(self, form):
        messages.success(self.request, 'Ingreso actualizado con exito')
        return super().form_valid(form)  
    
    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        context['incomes_view'] = True
        return context  
    
class DeleteIncomeView(LoginRequiredMixin, DeleteView):  
    login_url = reverse_lazy('login')      
    model = Income
    template_name = 'auth/incomes/delete.html'
    success_url = reverse_lazy('incomes')
    
    def form_valid(self, form):
        messages.success(self.request, 'Ingreso eliminado con exito')
        return super().form_valid(form)  
    
    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        context['incomes_view'] = True
        return context  
    
class IncomeDetailsView(LoginRequiredMixin, DetailView):
    login_url = reverse_lazy('login')
    model = Income
    context_object_name = 'income'
    template_name  = 'auth/incomes/details.html'
    
    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        context['incomes_view'] = True
        return context

class OutcomesView(LoginRequiredMixin, ListView):
    months = [
        ('1', 'Enero'), ('2', 'Febrero'), ('3', 'Marzo'), ('4', 'Abril'),
        ('5', 'Mayo'), ('6', 'Junio'), ('7', 'Julio'), ('8', 'Agosto'),
        ('9', 'Septiembre'), ('10', 'Octubre'), ('11',
                                                 'Noviembre'), ('12', 'Diciembre')
    ]
    
    login_url = reverse_lazy('login')
    model = Outcome
    template_name = 'auth/outcomes/index.html'
    context_object_name = 'outcomes'
    paginate_by = 10 
    
    def get_context_data(self, **kwargs):
        total_gastos =  Outcome.objects.aggregate( total=Sum('amount'))['total'] or 0
        total_impuestos = Outcome.objects.aggregate( impuestos=Sum('tax'))['impuestos'] or 0
        context = super().get_context_data(**kwargs)
        context['outcomes_view'] = True
        context['total_gastos'] = float(total_gastos + total_impuestos)
        context['months'] = self.months
        return context
    
class CreateOutcomeView(LoginRequiredMixin, CreateView):
    model = Outcome
    form_class = OutcomeForm
    template_name = 'auth/outcomes/create.html'
    success_url = reverse_lazy('outcomes')
    def form_valid(self, form):
        messages.success(self.request, 'Gasto registrado con exito')
        return super().form_valid(form)
    
    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        context['outcomes_view'] = True
        return context
         

class FilterOutcomesView(LoginRequiredMixin, View):
    login_url = reverse_lazy('login')
    
    months = [
        ('1', 'Enero'), ('2', 'Febrero'), ('3', 'Marzo'), ('4', 'Abril'),
        ('5', 'Mayo'), ('6', 'Junio'), ('7', 'Julio'), ('8', 'Agosto'),
        ('9', 'Septiembre'), ('10', 'Octubre'), ('11',
                                                 'Noviembre'), ('12', 'Diciembre')
    ]
    
    def get(self, request):
        term = request.GET.get('month')
        outcomes = Outcome.objects.filter(month__icontains=term).order_by('-id')
        context = {
            'outcomes': outcomes,
            'outcomes_view': True,
            'months': self.months 
        }
        return render(request, 'auth/outcomes/index.html', context)   
    
class UpdateOutcomeView(LoginRequiredMixin, UpdateView):
    model = Outcome
    template_name = 'auth/outcomes/update.html'
    form_class = OutcomeForm
    success_url = reverse_lazy('outcomes')
    
    def form_valid(self, form):
        messages.success(self.request, 'Gasto actualizado con exito')
        return super().form_valid(form) 
    
    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        context['outcomes_view'] = True
        return context
    
class DeleteOutcomeView(LoginRequiredMixin, DeleteView):
    login_url = reverse_lazy('login')
    model = Outcome
    template_name = 'auth/outcomes/delete.html'
    success_url = reverse_lazy('outcomes')
    
    def form_valid(self, form):
        messages.success(self.request, 'Gasto eliminado con exito')
        return super().form_valid(form)  
    
    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        context['outcomes_view'] = True
        context['months'] = self.months
        return context   
             
class OutcomeDetailsView(LoginRequiredMixin, DetailView):
    login_url = reverse_lazy('login')
    model = Outcome
    context_object_name = 'outcome'
    template_name  = 'auth/outcomes/details.html'
    
    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        context['outcomes_view'] = True
        return context

class UnpaidsView(LoginRequiredMixin, ListView):
    login_url = reverse_lazy('login')
    model = Unpaid
    template_name = 'auth/unpaids/index.html'
    context_object_name = 'unpaids'
    paginate_by = 10
    
class CreateUnpaidView(LoginRequiredMixin, CreateView):
    login_url = reverse_lazy('login')
    model = Unpaid
    form_class = UnpaidForm
    template_name = 'auth/unpaids/create.html'
    success_url = reverse_lazy('unpaids')
    def form_valid(self, form):
        messages.success(self.request, 'Mala paga registrado con exito')
        return super().form_valid(form)
    
    
class FilterUnpaidsView(LoginRequiredMixin, View):
    def get(self, request):
        term = request.GET.get('term')
        unpaids = Unpaid.objects.filter(Q(month=term) | Q(member__first_name__icontains=term)).order_by('-id')
        context = {
            'unpaids': unpaids,
            'active': True
        }
        return render(request, 'auth/unpaids/index.html', context)  
    

class UpdateUnpaidView(LoginRequiredMixin, UpdateView):
    login_url = reverse_lazy('login')
    model = Unpaid
    template_name = 'auth/unpaids/update.html'
    form_class = UnpaidForm
    success_url = reverse_lazy('unpaids')
    def form_valid(self, form):
        messages.success(self.request, 'Mala paga actualizado con exito')
        return super().form_valid(form)

class DeleteUnpaidView(LoginRequiredMixin, DeleteView):
    login_url = reverse_lazy('login')
    model = Unpaid
    template_name = 'auth/unpaids/delete.html'
    success_url = reverse_lazy('unpaids')
    
    def form_valid(self, form):
        messages.success(self.request, 'Mala paga eliminado con exito')
        return super().form_valid(form)    
    

class ConceptsView(LoginRequiredMixin, ListView):
    login_url = reverse_lazy('login')
    template_name = 'auth/concepts/index.html'
    model = Concept    
    ordering = '-id'
    context_object_name = 'concepts'
    
    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        context['concepts_view'] = True
        return context
    
class CreateConceptView(LoginRequiredMixin, CreateView):
    login_url = reverse_lazy('login')
    template_name = 'auth/concepts/create.html'
    model = Concept
    form_class = ConceptForm
    success_url = reverse_lazy('concepts')
    
    def form_valid(self, form):
        messages.success(self.request, 'Concepto agregado con exito')
        return super().form_valid(form)
    
    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        context['concepts_view'] = True
        return context
    
class UpdateConceptView(LoginRequiredMixin, UpdateView):
    login_url = reverse_lazy('login')
    template_name = 'auth/concepts/update.html'
    model = Concept
    form_class = ConceptForm
    success_url = reverse_lazy('concepts')
    
    def form_valid(self, form):
        messages.success(self.request, 'Concepto actualizado con exito')
        return super().form_valid(form)  
    
    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        context['concepts_view'] = True
        return context
    
class DeleteConceptView(LoginRequiredMixin, DeleteView):
    login_url = reverse_lazy('login')
    template_name = 'auth/concepts/delete.html'
    model = Concept
    success_url = reverse_lazy('concepts')
    
    def form_valid(self, form):
        messages.success(self.request, 'Concepto eliminado con exito')
        return super().form_valid(form)  
     
    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        context['concepts_view'] = True
        return context        