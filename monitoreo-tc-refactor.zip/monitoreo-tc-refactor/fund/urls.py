from django.urls import path
from . import views

urlpatterns =[
    path('', views.LoginView.as_view(), name='login'),
    path('dashboard/', views.DashboardView.as_view(), name='dashboard'),
    path('logout/', views.LogoutView.as_view(), name='logout'),
    
    # Members
    path('members/', views.MembersView.as_view(), name='members'),
    path('members/search/', views.FilterMemberView.as_view(), name='filter_member'),
    path('members/create/', views.CreateMemberView.as_view(), name='create_member'),
    path('members/<int:pk>/update/', views.UpdateMemberView.as_view(), name='update_member'),
    path('members/<int:pk>/delete/', views.DeleteMemberView.as_view(), name='delete_member'),
    
    #Birthdays
    path('birthdays/', views.BirthdaysView.as_view(), name='birthdays'),
    path('birthdays/filter', views.FilterBirthdaysView.as_view(), name='filter_birthdays'),
    
    #incomes
    path('incomes/', views.IncomesView.as_view(), name='incomes'),
    path('incomes/search/', views.FilterIncomesView.as_view(), name='filter_income'),
    path('incomes/<int:pk>/details/', views.IncomeDetailsView.as_view(), name='income_details'),
    path('incomes/create/', views.CreateIncomeView.as_view(), name='create_income'),
    path('incomes/<int:pk>/edit/', views.UpdateIncomeView.as_view(), name='update_income'),
    path('incomes/<int:pk>/delete/', views.DeleteIncomeView.as_view(), name='delete_income'),
    
    #outcomes
    path('outcomes/', views.OutcomesView.as_view(), name='outcomes'),
    path('outcomes/create/', views.CreateOutcomeView.as_view(), name='create_outcome'),
    path('outcomes/search/', views.FilterOutcomesView.as_view(), name='filter_outcome'),
    path('outcomes/<int:pk>/details/', views.OutcomeDetailsView.as_view(), name='outcome_details'),
    path('outcomes/<int:pk>/edit/', views.UpdateOutcomeView.as_view(), name='update_outcome'),
    path('outcomes/<int:pk>/delete/', views.DeleteOutcomeView.as_view(), name='delete_outcome'),
    
    #unpaids
    path('unpaids/', views.UnpaidsView.as_view(), name='unpaids'),
    path('unpaids/search/', views.FilterUnpaidsView.as_view(), name='filter_unpaids'),
    path('unpaids/create/', views.CreateUnpaidView.as_view(), name='create_unpaid'),
    path('unpaids/<int:pk>/edit/', views.UpdateUnpaidView.as_view(), name='update_unpaid'),
    path('unpaids/<int:pk>/delete/', views.DeleteUnpaidView.as_view(), name='delete_unpaid'),
    
    #concepts
    path('concepts/', views.ConceptsView.as_view(), name='concepts'),
    path('concepts/create/', views.CreateConceptView.as_view(), name='create_concept'),
    path('concepts/<int:pk>/edit/', views.UpdateConceptView.as_view(), name='update_concept'),
    path('concepts/<int:pk>/delete/', views.DeleteConceptView.as_view(), name='delete_concept'),
    
    
]