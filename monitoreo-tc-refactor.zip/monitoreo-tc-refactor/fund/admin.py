from django.contrib import admin
from .models import Income, Member, Outcome, Concept, Unpaid

# Register your models here.


admin.site.register(Member)
admin.site.register(Income)
admin.site.register(Outcome)
admin.site.register(Concept)
admin.site.register(Unpaid)