from django import forms
from .models import Member, Concept, Income, Outcome, Unpaid


class LoginForm(forms.Form):
    username = forms.CharField(
        error_messages={'required': 'El campo username no puede estar vacio'},
        widget=forms.TextInput(attrs={"autofocus": True, 'class': 'form-control my-3'}))

    password = forms.CharField(
        error_messages={'required': 'El campo password no puede estar vacio'},
        strip=False,
        widget=forms.PasswordInput(attrs={"autocomplete": "current-password",'class': 'form-control my-3'}),
    )




class MemberForm(forms.ModelForm):
    class Meta:

        model = Member
        exclude = ('uuid', 'created_at', 'updated_at')
        widgets = {
            'first_name': forms.TextInput(attrs={'class': 'form-control mb-2', 'placeholder':'Nombre del miembro'}),
            'last_name': forms.TextInput(attrs={'class': 'form-control mb-2', 'placeholder':'Apellido del miembro'}),
            'status': forms.CheckboxInput(attrs={'class': 'form-check-input mb-3'}),
            'birthday_day': forms.TextInput(attrs={'class': 'form-control mb-2', 'placeholder':'Dia de nacimiento, ej: 21'}),
            'birthday_month': forms.Select(attrs={'class': 'form-control mb-2'})
        }
        
        labels = {
            'first_name': 'Nombre',
            'last_name': 'Apellido',
            'status': 'Activo',
            'birthday_day': 'Dia de Nacimiento',
            'birthday_month': 'Mes de Nacimiento'
        }

class ConceptForm(forms.ModelForm):

    class Meta:
        model = Concept
        exclude = ('uuid', 'created_at', 'updated_at')

        widgets = {
            'name': forms.TextInput(attrs={'class': 'form-control'})
        }
class IncomeForm(forms.ModelForm):
    class Meta:
        model = Income
        exclude = ('uuid', 'created_at', 'updated_at')
        widgets = {
            'member': forms.Select(attrs={'class': 'form-select mb-2'}),
            'amount': forms.TextInput(attrs={'class': 'form-control mb-2'}),
            'month': forms.Select(attrs={'class': 'form-select mb-2'}),
            'concept': forms.Select(attrs={'class': 'form-control mb-2'}),
            'note': forms.Textarea(attrs={'class': 'form-control mb-2', 'rows': 3})
        }
        
        labels ={
            'member': 'Miembro',
            'amount': 'Monto',
            'month': 'Mes',
            'concept': 'Concepto',
            'note': 'Nota'
        }

class OutcomeForm(forms.ModelForm):
    class Meta:
        model = Outcome
        exclude = ('uuid', 'created_at', 'updated_at')
        widgets = {
            'amount': forms.TextInput(attrs={'class': 'form-control mb-2'}),
            'tax': forms.TextInput(attrs={'class': 'form-control mb-2'}),
            'month': forms.Select(attrs={'class': 'form-select mb-2'}),
            'concept': forms.Select(attrs={'class': 'form-select mb-2'}),
            'note': forms.Textarea(attrs={'class': 'form-control mb-2'})
        }
        
        labels = {
            'amount': 'Monto',
            'tax': 'Impuesto',
            'month': 'Mes',
            'concept': 'Concepto',
            'note': 'Notas'
        }     

class UnpaidForm(forms.ModelForm):
    class Meta:
        model = Unpaid
        exclude = ('uuid', 'created_at', 'updated_at')
        widgets = {
            'member': forms.Select(attrs={'class': 'form-select mb-2'}),
            'month': forms.Select(attrs={'class': 'form-select mb-2'})
        }   
        
        labels = {
            'member': 'Miembro',
            'month': 'Mes'
        }     