from django.db import models
from uuid import uuid4
from django.db.models.aggregates import Sum

MONTH_CHOICES = (
        ('1', 'Enero'), ('2', 'Febrero'), ('3', 'Marzo'), ('4', 'Abril'),
        ('5', 'Mayo'), ('6', 'Junio'), ('7', 'Julio'), ('8', 'Agosto'),
        ('9', 'Septiembre'), ('10', 'Octubre'),('11', 'Noviembre'), ('12', 'Diciembre')
    )

class Member(models.Model):

    uuid = models.UUIDField(blank=False, null=False, default=uuid4())
    first_name = models.CharField(max_length=60, null=False, blank=False)
    last_name = models.CharField(max_length=60, null=False, blank=False)
    status = models.BooleanField(default=True, null=False, blank=False)
    birthday_day = models.CharField(max_length=3, null=False, blank=False)
    birthday_month = models.CharField(max_length=20, null=False, blank=False, choices=MONTH_CHOICES)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    def __str__(self):
        return f"{self.first_name} {self.last_name}"

class Concept(models.Model):
    uuid = models.UUIDField(blank=False, null=False, default=uuid4())
    name = models.CharField(max_length=60, null=False, blank=False)
    created_at = models.DateField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)


    def __str__(self):
        return self.name

class Income(models.Model):
    uuid = models.UUIDField(blank=False, null=False, default=uuid4())
    member = models.ForeignKey(Member, on_delete=models.CASCADE)
    amount = models.DecimalField(max_digits=10, decimal_places=2, null=False, blank=False)
    month = models.CharField(max_length=60, null=False, blank=False, choices=MONTH_CHOICES)
    concept =  models.ForeignKey(Concept, on_delete=models.CASCADE)
    note = models.TextField(null=True, blank=True)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True, null=True, blank=True)

    def __str__(self):
        return f"{self.member.first_name} {self.member.last_name} - RD$ {self.amount} - {self.month}"
    

class Outcome(models.Model):
    uuid = models.UUIDField(blank=False, null=False, default=uuid4())
    amount = models.DecimalField(max_digits=10, decimal_places=2, null=False, blank=False)
    tax = models.DecimalField(max_digits=10, decimal_places=2, null=True, blank=True)
    month = models.CharField(max_length=60, null=False, blank=False, choices=MONTH_CHOICES)
    concept =  models.ForeignKey(Concept, on_delete=models.CASCADE)
    note = models.TextField(null=True, blank=True)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    def __str__(self):
        return f"{self.month} - RD${self.amount} - {self.concept}"


class Unpaid(models.Model):
    uuid = models.UUIDField(blank=False, null=False, default=uuid4())
    member = models.ForeignKey(Member, on_delete=models.CASCADE)
    month = models.CharField(max_length=60, null=False, blank=False, choices=MONTH_CHOICES)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    def __str__(self):
        return f"{self.member.first_name} {self.member.last_name} - {self.month}" 